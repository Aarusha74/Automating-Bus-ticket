<?php 
session_start();
  include("connection.php");
  include("functions.php");
  
  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];
    if(!empty($user_name) && !empty($password))
    {
      $query = "select * from users where user_name = 'hdubey' limit 1";
      $result = mysqli_query($con,$query);

      if($result)
      {
        if($result && mysqli_num_rows($result) > 0)
        {
          $user_data = mysqli_fetch_assoc($result);
          
          if($user_data['password'] === "admin"){
            $_SESSION['user_id'] = $user_data['id'];
            header("Location: userAccount.php");
            die;
          }
        }
      }
    }else
    {
      echo "Please enter valid information!";
    }
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Bus ticket automation system</title>
  <script src="https://kit.fontawesome.com/260c81d715.js" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="user.css">
</head>

<body>
  <section class="top" id="home">


    <div class="container-fluid top-cd">

      <nav class="navbar navbar-expand-md navbar-light ">
        <a class="navbar-brand" href="#home">Group 4</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="index.html#about">About</a></li>
            <li class="nav-item"><a class="nav-link" href="index.html#updates">Updates</a></li>
            <li class="nav-item"><a class="nav-link" href="user.html">User</a></li>
          </ul>
        </div>
      </nav>
      <div class="formd">

      <form method="post">
        <div class="imgcontainer">
          <i class="fas fa-bus avatar"></i>
        </div>

        <div class="container">
          <label for="uname"><b>Username</b></label>
          <input class="tbox" type="text" placeholder="Enter Username" name="user_name" required>

          <label for="psw"><b>Password</b></label>
          <input class="tbox" type="password" placeholder="Enter Password" name="password" required>

          <button class="tbox" type="submit">Login</button>
          <div class="afterSub">
          <label>
            <input type="checkbox" checked="checked" name="remember"> Remember me
          </label>
            <span class="psw">Forgot <a class="link-primary linkstyle" href="#">password?</a></span>
            </div>
        </div>

        <div class="container-su" style="background-color:#171717">
          <div class="signup">
          <span>New User?</span>
          <button type="button" class="cancelbtn" onclick="document.location= 'signup.php'">Sign Up</button>
        </div>
        </div>
      </form>
    </div>
    </div>
  </section>
  <section class="end">
    <div class="Footer">
      <a href="#" class="c-link"><i class="fab fa-github"></i></a>
      <a href="" class="c-link"><i class="fab fa-instagram"></i></a>
      <a href="" class="c-link"><i class="fab fa-twitter"></i></a>
      <a href="" class="c-link"><i class="fas fa-envelope"></i></a>
    </div>
  </section>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>

</html>

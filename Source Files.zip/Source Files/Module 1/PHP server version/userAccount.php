<?php 
session_start();
  include("connection.php");
  include("functions.php");
  
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Bus ticket automation system</title>
  <script src="https://kit.fontawesome.com/260c81d715.js" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="user.css">
</head>
  <body>
    <section class="top" id="home">


      <div class="container-fluid top-cd">

        <nav class="navbar navbar-expand-md navbar-light ">
          <a class="navbar-brand" href="#home">Group 4</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <ul class="navbar-nav ms-auto">
              <li class="nav-item"><a class="nav-link" href="C:\Users\Hrishikesh Dubey\Documents\SRM\4th Semester\Software\Bus ticket automation system\index.html">Home</a></li>
              <li class="nav-item"><a class="nav-link" href="C:\Users\Hrishikesh Dubey\Documents\SRM\4th Semester\Software\Bus ticket automation system\index.html#about">About</a></li>
              <li class="nav-item"><a class="nav-link" href="C:\Users\Hrishikesh Dubey\Documents\SRM\4th Semester\Software\Bus ticket automation system\index.html#updates">Updates</a></li>
              <li class="nav-item"><a class="nav-link" href="user.html">User</a></li>
            </ul>
          </div>
        </nav>
        <div class="formd">

      <form action="action_page.php" method="post">
        <div class="imgcontainer">
          <i class="fas fa-bus avatar"></i>
        </div>

        <div class="container">
          <label for="uname"><b>Credits in INR</b></label>
          <input class="tbox" type="text" placeholder="Enter Username" name="uname" required>

          <label for="psw"><b>Method of Payment</b></label><br>
          <input id="payment" class="tbox" list="payment" width="100%" >
          <datalist id="payment">
            <option value="Debit Card"></option>
            <option value="Credit Card"></option>
            <option value="Net Banking"></option>
            <option value="UPI"></option>
          </datalist>
          <button class="tbox" type="submit">Add Credits</button>
          <div class="afterSub">
          <label>
          
          </label>
            <span class="psw">Change <a class="link-primary linkstyle" href="#">password?</a></span>
            </div>
        </div>

        <div class="container-su" style="background-color:#171717">
          <div class="signup">
          <button type="button" class="cancelbtn" onclick="document.location= 'user.html'">Log Out</button>
        </div>
        </div>
      </form>
    </div>
        </div>
        </section>
  </body>
</html>

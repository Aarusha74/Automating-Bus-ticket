import machine
from machine import  I2C, Pin
import ssd1306
import PN532
from time import sleep

# ESP32 Pin assignment 
i2c = I2C(-1, scl=Pin(22), sda=Pin(21))

# ESP8266 Pin assignment
#i2c = I2C(-1, scl=Pin(5), sda=Pin(4))

oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

b1 = machine.Pin(16, machine.Pin.IN, machine.Pin.PULL_DOWN)
b2 = machine.Pin(17, machine.Pin.IN, machine.Pin.PULL_DOWN)
b3 = machine.Pin(10, machine.Pin.IN, machine.Pin.PULL_DOWN)
b4 = machine.Pin(9, machine.Pin.IN, machine.Pin.PULL_DOWN)

while True:
  if(b1.value()==1):
      oled.fill(0)
      oled.text('Bus Stop 1',0,10)
      oled.text('Tap card to pay',0,30)
  if(b2.value()==1):
      oled.fill(0)
      oled.text('Bus Stop 2',0,10)
      oled.text('Tap card to pay',0,30)
  if(b3.value()==1):
      oled.fill(0)
      oled.text('Bus Stop 3',0,10)
      oled.text('Tap card to pay',0,30)
  if(b4.value()==1):
      oled.fill(0)
      oled.text('Bus Stop 4',0,10)
      oled.text('Tap card to pay',0,30)
      
  oled.show()
  sleep(0.2)